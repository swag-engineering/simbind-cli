from functools import wraps

from .BaseModel import BaseModel
from . import ClimateController2023a


def collect(func):
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if self.collector_callback:
            in_data = {
                "EngineSpeed": self.input.EngineSpeed,
                "UserSetpointInCelsius": self.input.UserSetpointInCelsius,
                "ExternalTemperatureInCelsius": self.input.ExternalTemperatureInCelsius,
                "RecyclingAir": self.input.RecyclingAir,
                "Distribution": self.input.Distribution
            }
            out_data = {
                "AdditionalLoading": self.output.AdditionalLoading,
                "Tcabin": self.output.Tcabin,
                "ReqTout": self.output.ReqTout,
                "FlapPos": self.output.FlapPos
            }
            self.collector_callback(self.time, in_data, out_data)
        return func(self, *args, **kwargs)
    return wrapper


class Input:
    @property
    def EngineSpeed(self) -> float:
        return ClimateController2023a.cvar.ClimateController2023a_U.EngineSpeed

    @EngineSpeed.setter
    def EngineSpeed(self, value: float):
        ClimateController2023a.cvar.ClimateController2023a_U.EngineSpeed = value
    
    @property
    def UserSetpointInCelsius(self) -> float:
        return ClimateController2023a.cvar.ClimateController2023a_U.UserSetpointInCelsius

    @UserSetpointInCelsius.setter
    def UserSetpointInCelsius(self, value: float):
        ClimateController2023a.cvar.ClimateController2023a_U.UserSetpointInCelsius = value
    
    @property
    def ExternalTemperatureInCelsius(self) -> float:
        return ClimateController2023a.cvar.ClimateController2023a_U.ExternalTemperatureInCelsius

    @ExternalTemperatureInCelsius.setter
    def ExternalTemperatureInCelsius(self, value: float):
        ClimateController2023a.cvar.ClimateController2023a_U.ExternalTemperatureInCelsius = value
    
    @property
    def RecyclingAir(self) -> float:
        return ClimateController2023a.cvar.ClimateController2023a_U.RecyclingAir

    @RecyclingAir.setter
    def RecyclingAir(self, value: float):
        ClimateController2023a.cvar.ClimateController2023a_U.RecyclingAir = value
    
    @property
    def Distribution(self) -> float:
        return ClimateController2023a.cvar.ClimateController2023a_U.Distribution

    @Distribution.setter
    def Distribution(self, value: float):
        ClimateController2023a.cvar.ClimateController2023a_U.Distribution = value
    

class Output:
    @property
    def AdditionalLoading(self) -> float:
        return ClimateController2023a.cvar.ClimateController2023a_Y.AdditionalLoading
    
    @property
    def Tcabin(self) -> int:
        return ClimateController2023a.cvar.ClimateController2023a_Y.Tcabin
    
    @property
    def ReqTout(self) -> float:
        return ClimateController2023a.cvar.ClimateController2023a_Y.ReqTout
    
    @property
    def FlapPos(self) -> float:
        return ClimateController2023a.cvar.ClimateController2023a_Y.FlapPos
    

class Model(BaseModel):
    def __init__(self, collector_callback=None):
        self.collector_callback = collector_callback
        self._input = Input()
        self._output = Output()
        self.initialize()

    @property
    def input(self) -> Input:
        """
        Input interface of the model. Available properties:
            EngineSpeed: float
            UserSetpointInCelsius: float
            ExternalTemperatureInCelsius: float
            RecyclingAir: float
            Distribution: float
        """
        return self._input

    @property
    def output(self) -> Output:
        """
        Output interface of the model. Available properties:
            AdditionalLoading: float
            Tcabin: int
            ReqTout: float
            FlapPos: float
        """
        return self._output

    @property
    def _rt_model(self) -> ClimateController2023a.tag_RTM_ClimateController2023a_T:
        return ClimateController2023a.cvar.ClimateController2023a_M

    @property
    def time(self) -> float:
        return ClimateController2023a.rtmGetT(self._rt_model)

    def initialize(self) -> None:
        return ClimateController2023a.ClimateController2023a_initialize()

    @collect
    def step(self) -> None:
        return ClimateController2023a.ClimateController2023a_step()

    @collect
    def terminate(self) -> None:
        return ClimateController2023a.ClimateController2023a_terminate()
