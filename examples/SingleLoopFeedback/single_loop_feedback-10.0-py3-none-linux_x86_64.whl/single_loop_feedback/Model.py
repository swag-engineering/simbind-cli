from functools import wraps

from .BaseModel import BaseModel
from . import SingleLoopFeedback2023a


def collect(func):
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if self.collector_callback:
            in_data = {
                "speed_reference": self.input.speed_reference
            }
            out_data = {
                "out": self.output.out
            }
            self.collector_callback(self.time, in_data, out_data)
        return func(self, *args, **kwargs)
    return wrapper


class Input:
    @property
    def speed_reference(self) -> float:
        return SingleLoopFeedback2023a.cvar.SingleLoopFeedback2023a_U.speed_reference

    @speed_reference.setter
    def speed_reference(self, value: float):
        SingleLoopFeedback2023a.cvar.SingleLoopFeedback2023a_U.speed_reference = value
    

class Output:
    @property
    def out(self) -> float:
        return SingleLoopFeedback2023a.cvar.SingleLoopFeedback2023a_Y.out
    

class Model(BaseModel):
    def __init__(self, collector_callback=None):
        self.collector_callback = collector_callback
        self._input = Input()
        self._output = Output()
        self.initialize()

    @property
    def input(self) -> Input:
        """
        Input interface of the model. Available properties:
            speed_reference: float
        """
        return self._input

    @property
    def output(self) -> Output:
        """
        Output interface of the model. Available properties:
            out: float
        """
        return self._output

    @property
    def _rt_model(self) -> SingleLoopFeedback2023a.tag_RTM_SingleLoopFeedback2023a_T:
        return SingleLoopFeedback2023a.cvar.SingleLoopFeedback2023a_M

    @property
    def time(self) -> float:
        return SingleLoopFeedback2023a.rtmGetT(self._rt_model)

    def initialize(self) -> None:
        return SingleLoopFeedback2023a.SingleLoopFeedback2023a_initialize()

    @collect
    def step(self) -> None:
        return SingleLoopFeedback2023a.SingleLoopFeedback2023a_step()

    @collect
    def terminate(self) -> None:
        return SingleLoopFeedback2023a.SingleLoopFeedback2023a_terminate()
