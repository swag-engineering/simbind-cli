from functools import wraps

from .BaseModel import BaseModel
from . import LongitudinalFlightControl2023aa


def collect(func):
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if self.collector_callback:
            in_data = {
                "stick": self.input.stick
            }
            out_data = {
                "alpharad": self.output.alpharad
            }
            self.collector_callback(self.time, in_data, out_data)
        return func(self, *args, **kwargs)
    return wrapper


class Input:
    @property
    def stick(self) -> float:
        return LongitudinalFlightControl2023aa.cvar.LongitudinalFlightControl2023aa_U.stick

    @stick.setter
    def stick(self, value: float):
        LongitudinalFlightControl2023aa.cvar.LongitudinalFlightControl2023aa_U.stick = value
    

class Output:
    @property
    def alpharad(self) -> float:
        return LongitudinalFlightControl2023aa.cvar.LongitudinalFlightControl2023aa_Y.alpharad
    

class Model(BaseModel):
    def __init__(self, collector_callback=None):
        self.collector_callback = collector_callback
        self._input = Input()
        self._output = Output()
        self.initialize()

    @property
    def input(self) -> Input:
        """
        Input interface of the model. Available properties:
            stick: float
        """
        return self._input

    @property
    def output(self) -> Output:
        """
        Output interface of the model. Available properties:
            alpharad: float
        """
        return self._output

    @property
    def _rt_model(self) -> LongitudinalFlightControl2023aa.tag_RTM_LongitudinalFlightControl2023aa_T:
        return LongitudinalFlightControl2023aa.cvar.LongitudinalFlightControl2023aa_M

    @property
    def time(self) -> float:
        return LongitudinalFlightControl2023aa.rtmGetT(self._rt_model)

    def initialize(self) -> None:
        return LongitudinalFlightControl2023aa.LongitudinalFlightControl2023aa_initialize()

    @collect
    def step(self) -> None:
        return LongitudinalFlightControl2023aa.LongitudinalFlightControl2023aa_step()

    @collect
    def terminate(self) -> None:
        return LongitudinalFlightControl2023aa.LongitudinalFlightControl2023aa_terminate()
