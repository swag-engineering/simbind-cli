from functools import wraps

from .BaseModel import BaseModel
from . import AntiWindupPidController2023a


def collect(func):
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if self.collector_callback:
            in_data = {
                "rt": self.input.rt
            }
            out_data = {
                "yout": self.output.yout
            }
            self.collector_callback(self.time, in_data, out_data)
        return func(self, *args, **kwargs)
    return wrapper


class Input:
    @property
    def rt(self) -> float:
        return AntiWindupPidController2023a.cvar.AntiWindupPidController2023a_U.rt

    @rt.setter
    def rt(self, value: float):
        AntiWindupPidController2023a.cvar.AntiWindupPidController2023a_U.rt = value
    

class Output:
    @property
    def yout(self) -> float:
        return AntiWindupPidController2023a.cvar.AntiWindupPidController2023a_Y.yout
    

class Model(BaseModel):
    def __init__(self, collector_callback=None):
        self.collector_callback = collector_callback
        self._input = Input()
        self._output = Output()
        self.initialize()

    @property
    def input(self) -> Input:
        """
        Input interface of the model. Available properties:
            rt: float
        """
        return self._input

    @property
    def output(self) -> Output:
        """
        Output interface of the model. Available properties:
            yout: float
        """
        return self._output

    @property
    def _rt_model(self) -> AntiWindupPidController2023a.tag_RTM_AntiWindupPidController2023a_T:
        return AntiWindupPidController2023a.cvar.AntiWindupPidController2023a_M

    @property
    def time(self) -> float:
        return AntiWindupPidController2023a.rtmGetT(self._rt_model)

    def initialize(self) -> None:
        return AntiWindupPidController2023a.AntiWindupPidController2023a_initialize()

    @collect
    def step(self) -> None:
        return AntiWindupPidController2023a.AntiWindupPidController2023a_step()

    @collect
    def terminate(self) -> None:
        return AntiWindupPidController2023a.AntiWindupPidController2023a_terminate()
